<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>ClyvoVet_Default_Suite_v5</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>1d3f6adc-55bf-4114-88a7-b4d334cdd3b9</testSuiteGuid>
   <testCaseLink>
      <guid>03771c43-24de-4d80-afff-09595f138918</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ClyvoVet_Default_Suite_v5/TC02_Login_Invalido</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a27febc2-6f4f-4439-b49e-7c42de34711a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ClyvoVet_Default_Suite_v5/TC01_Login_Valido</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>bd1b7ed3-f2a7-412f-9b93-e8b2d75f1eca</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ClyvoVet_Default_Suite_v5/TC03_Criar_Atendimento</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>3b66da49-8278-48f1-a2ea-14a27c1608f6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ClyvoVet_Default_Suite_v5/TC04_Novo_Pet</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>401d559d-6e83-4990-8e81-2a399d1e876f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ClyvoVet_Default_Suite_v5/TC05_Prescrever_Medicamento</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    
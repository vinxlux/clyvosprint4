import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://clyvovet.vercel.app/consultas?status=CONCLUIDA")
Thread.sleep(1500);
selenium.click("link=Abrir")
Thread.sleep(1500);
selenium.click("link=Prescrever medicamento")
Thread.sleep(1500);
selenium.type("id=nome", "Carprofeno")
selenium.type("id=principioAtivo", ("Anti-inflamat�rio n�o esteroidal (AINE)").toString())
selenium.type("id=dosagem", "75mg")
selenium.type("id=frequencia", ("a cada 12 horas").toString())
selenium.type("id=dataFim", ("2030-12-02").toString())
selenium.type("id=observacoes", ("Administrar junto ou logo ap�s as refei��es para evitar desconforto g�strico. Manter �gua limpa e fresca sempre � disposi��o. Suspender o uso e contatar o veterin�rio caso observe v�mitos, fezes escuras ou perda de apetite.").toString())
selenium.click("xpath=//button[contains(.,'Prescrever')]")
Thread.sleep(2000);
assertFalse(selenium.isElementPresent("id=dosagem"));
softAssertion.assertEquals(selenium.isTextPresent("Carprofeno"), true)
